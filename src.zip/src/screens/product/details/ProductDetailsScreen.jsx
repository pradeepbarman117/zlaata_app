import { View, Text } from 'react-native'
import React from 'react'
import ProductDetailsCarousel from '../../../components/product/details/ProductDetailsCarousel'
import ProductDetailsContent from '../../../components/product/details/ProductDetailsContent'

const ProductDetailsScreen = () => {
  return (
    <>
      <View style={{backgroundColor:'white',flex:1}}>
        <View style={{ height: 430 }}>
          <ProductDetailsCarousel />
        </View>
        <View>
          <ProductDetailsContent />
        </View>
      </View>
    </>
  )
}

export default ProductDetailsScreen